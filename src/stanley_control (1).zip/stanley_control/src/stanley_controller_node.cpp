#include <ros/ros.h>
#include <math.h>
#include <std_msgs/Float32MultiArray.h>
#include <ackermann_msgs/AckermannDriveStamped.h>
#include <std_msgs/Float64.h>  // current_velocity를 받을 때 사용
#include <vector>
#include <Eigen/Dense>

double wheel_base = 0.75;
std::vector<double> steer_angle;
std::vector<double> cte_list;
std::vector<double> cte_term_list;
std::vector<double> angular_velocity_list;
std::vector<double> heading_error_term_list;
std::vector<double> feedforward_term_list;
double steering_vel_constraint = 150; // 핸들의 조향속도를 제한
double max_rad = 0.2618; // 최대 조향각을 라디안으로 제한 (15도)
double min_rad = -0.2618;
double soft_term = 2.0; // 속도가 낮을 때 조향 불안정성을 완화하기 위한 값
double velocity = 0.0;
double p_gain = 0.2; // CTE에 대한 비례 이득
double h_gain = 0.3; // 헤딩 에러에 대한 비례 이득
double f_gain = 0.3; // 피드포워드 제어 이득
double dt = 0.025; // 시간 간격
double prev_delta = 0.0; // 이전 조향각
ros::Publisher pubAckermann;

// current_velocity를 구독할 때 사용하는 콜백 함수
void velocityCallback(const std_msgs::Float64::ConstPtr& msg) {
    velocity = msg->data;
}

void errorCallback(const std_msgs::Float32MultiArray::ConstPtr& msg) {
    double a3 = msg->data[0];
    double a2 = msg->data[1];
    double a1 = msg->data[2];
    double a0 = msg->data[3];

    // 경로 곡률을 이용한 피드포워드 제어
    double n = 3 * a3 * pow(2.5, 2) + 2 * a2 * 2.5 + a1;
    double n_2 = 6 * a3 * 2.5 + 2 * a2;
    double radius = ((pow(n, 2) + 1) * sqrt(pow(n, 2) + 1)) / n_2;
    double feedforward_term = f_gain * atan(wheel_base / radius);
    feedforward_term_list.push_back(feedforward_term * 180 / M_PI); // 단위 변환

    // 주행 경로에서의 CTE 계산
    double cte = a3 * pow(7, 3) + a2 * pow(7, 2) + a1 * 7 + a0;
    cte = std::max(std::min(cte, 3.0), -3.0); // CTE를 -3에서 3 사이로 제한
    cte_list.push_back(cte);

    // CTE에 대한 조향 명령 계산
    double crosstrack_error_term = p_gain * atan((p_gain * cte) / (velocity + soft_term));
    cte_term_list.push_back(crosstrack_error_term * 180 / M_PI); // 단위 변환

    // 헤딩 에러 계산
    double heading_error_term = h_gain * atan(n);
    heading_error_term_list.push_back(heading_error_term * 180 / M_PI); // 단위 변환

    // 최종 조향각 계산 및 제한 적용
    double delta = crosstrack_error_term + heading_error_term + feedforward_term;
    delta = std::max(std::min(delta, max_rad), min_rad); // 최대/최소 조향각 제한

    // 조향속도 제어
    double delta_rate = (delta - prev_delta) * 180 / M_PI / dt; // 단위 변환 후 조향각 변화율 계산
    if (delta_rate > steering_vel_constraint) { // 최대 조향 속도 제한
        delta = prev_delta + steering_vel_constraint * dt * M_PI / 180;
    } else if (delta_rate < -steering_vel_constraint) {
        delta = prev_delta - steering_vel_constraint * dt * M_PI / 180;
    }

    // 조향각 및 각속도 저장
    steer_angle.push_back(delta * 180 / M_PI); // 단위 변환 후 저장
    angular_velocity_list.push_back(delta_rate);

    // 이전 조향각 업데이트
    prev_delta = delta;

    // Ackermann 제어 메시지 생성 및 퍼블리시
    ackermann_msgs::AckermannDriveStamped commandOut;
    commandOut.header.stamp = ros::Time::now();
    commandOut.header.frame_id = "base_link";
    commandOut.drive.steering_angle = delta; // 조향각 그대로 사용
    pubAckermann.publish(commandOut);
}

int main(int argc, char** argv) {
    ros::init(argc, argv, "stanley_controller_node");
    ros::NodeHandle nh;

    pubAckermann = nh.advertise<ackermann_msgs::AckermannDriveStamped>("/Ackermann/command/auto", 10);

    // coefficients와 current_velocity 구독
    ros::Subscriber sub_coeff = nh.subscribe("coefficients", 10, errorCallback);
    ros::Subscriber sub_velocity = nh.subscribe("current_velocity", 10, velocityCallback);

    ros::spin();
    return 0;
}
